// student_choice_backend/server.js
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const User = require("./models/User");
const Product = require("./models/Product");
const Review = require("./models/Review");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/student_choice", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Register
app.post("/api/register", async (req, res) => {
  const { email, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  try {
    const user = await User.create({ email, password: hashedPassword });
    res.json(user);
  } catch (err) {
    res.status(400).json({ error: "User already exists" });
  }
});

// Login
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).json({ error: "User not found" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (isMatch) {
    res.json({ message: "Login success" });
  } else {
    res.status(401).json({ error: "Invalid credentials" });
  }
});

// Upload Product URLs (up to 10 per section)
app.post("/api/upload", async (req, res) => {
  const { section, urls } = req.body;
  if (!section || !urls || urls.length > 10) {
    return res.status(400).json({ error: "Provide up to 10 URLs per section" });
  }
  const product = await Product.create({ section, urls });
  res.json(product);
});

// Get Products by Section
app.get("/api/products/:section", async (req, res) => {
  const { section } = req.params;
  const products = await Product.find({ section });
  res.json(products);
});

// Add Review
app.post("/api/reviews", async (req, res) => {
  const { username, comment, rating } = req.body;
  const review = await Review.create({ username, comment, rating });
  res.json(review);
});

// Get All Reviews
app.get("/api/reviews", async (req, res) => {
  const reviews = await Review.find();
  res.json(reviews);
});

app.listen(5000, () => console.log("Server started on port 5000"));
